     7
Ovulgaris         
Emoschata           0.1048
Cmacropus           0.0648  0.1154
Ecirrhosa           0.0918  0.0423  0.1109
Ptetracitrrhus      0.0717  0.1216  0.0470  0.1146
Sunicirrhus         0.0729  0.0989  0.0504  0.0797  0.0584
Aargo               0.1118  0.1342  0.1203  0.1230  0.1269  0.1137
