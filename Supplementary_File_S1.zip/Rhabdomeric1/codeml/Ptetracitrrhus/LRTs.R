# m0 VS m2
model_g_LnL <- -3675.883443
model_g_np <- 2
model_a_LnL <- -3675.872510
model_a_np <- 3
LRT <- -2*(model_g_LnL-model_a_LnL)
degrees.of.freedom <- model_a_np-model_g_np
p.value <- 1-pchisq(LRT,df=degrees.of.freedom)
p.value

# m2 VS m1
model_g_LnL <- -3675.872510
model_g_np <- 3
model_a_LnL <- -3653.787097
model_a_np <- 12
LRT <- -2*(model_g_LnL-model_a_LnL)
degrees.of.freedom <- model_a_np-model_g_np
p.value <- 1-pchisq(LRT,df=degrees.of.freedom)
p.value

# m0 VS m1
model_g_LnL <- -3675.883443
model_g_np <- 2
model_a_LnL <- -3653.787097
model_a_np <- 12
LRT <- -2*(model_g_LnL-model_a_LnL)
degrees.of.freedom <- model_a_np-model_g_np
p.value <- 1-pchisq(LRT,df=degrees.of.freedom)
p.value

# msites_gen VS msites_alt
model_g_LnL <- -3605.613583
model_g_np <- 4
model_a_LnL <- -3602.558942
model_a_np <- 5
LRT <- -2*(model_g_LnL-model_a_LnL)
degrees.of.freedom <- model_a_np-model_g_np
p.value <- 1-pchisq(LRT,df=degrees.of.freedom)
p.value
