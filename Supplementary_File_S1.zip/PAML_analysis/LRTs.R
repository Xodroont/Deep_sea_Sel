# m0 VS m1
model_g_LnL <- -3615.051453
model_g_np <- 2
model_a_LnL <- -3595.057768
model_a_np <- 12
LRT_m0VSm1 <- -2*(model_g_LnL-model_a_LnL)
degrees.of.freedom <- model_a_np-model_g_np
p.value_m0VSm1 <- 1-pchisq(LRT_m0VSm1,df=degrees.of.freedom)
LRT_m0VSm1
p.value_m0VSm1


# m0 VS m2
model_g_LnL <- -3615.051453
model_g_np <- 2
model_a_LnL <- -3610.895069 
model_a_np <- 3
LRT_m0VSm2_deep <- -2*(model_g_LnL-model_a_LnL)
degrees.of.freedom <- model_a_np-model_g_np
p.value_m0VSm2_deep <- 1-pchisq(LRT_m0VSm2_deep,df=degrees.of.freedom)
LRT_m0VSm2_deep
p.value_m0VSm2_deep

# m0 VS m2
model_g_LnL <- -3615.051453
model_g_np <- 2
model_a_LnL <- -3614.519069 
model_a_np <- 3
LRT_m0VSm2_lit <- -2*(model_g_LnL-model_a_LnL)
degrees.of.freedom <- model_a_np-model_g_np
p.value_m0VSm2_lit <- 1-pchisq(LRT_m0VSm2_lit,df=degrees.of.freedom)
LRT_m0VSm2_lit
p.value_m0VSm2_lit

# m0 VS m2
model_g_LnL <- -3615.051453
model_g_np <- 2
model_a_LnL <- -3603.541179 
model_a_np <- 3
LRT_m0VSm2_PT <- -2*(model_g_LnL-model_a_LnL)
degrees.of.freedom <- model_a_np-model_g_np
p.value_m0VSm2_PT <- 1-pchisq(LRT_m0VSm2_PT,df=degrees.of.freedom)
LRT_m0VSm2_PT
p.value_m0VSm2_PT

# msites_gen VS msites_alt
model_g_LnL <- -3606.745186 
model_g_np <- 4
model_a_LnL <- -3600.416101
model_a_np <- 5
LRT_gen_alt_deep <- -2*(model_g_LnL-model_a_LnL)
degrees.of.freedom <- model_a_np-model_g_np
p.value_gen_alt_deep <- 1-pchisq(LRT_gen_alt_deep,df=degrees.of.freedom)
LRT_gen_alt_deep
p.value_gen_alt_deep

# msites_gen VS msites_alt
model_g_LnL <- -3606.235993 
model_g_np <- 4
model_a_LnL <- -3605.922075
model_a_np <- 5
LRT_gen_alt_lit <- -2*(model_g_LnL-model_a_LnL)
degrees.of.freedom <- model_a_np-model_g_np
p.value_gen_alt_lit <- 1-pchisq(LRT_gen_alt_lit,df=degrees.of.freedom)
LRT_gen_alt_lit
p.value_gen_alt_lit

# msites_gen VS msites_alt
model_g_LnL <- -3591.298308 
model_g_np <- 4
model_a_LnL <- -3586.166334
model_a_np <- 5
LRT_gen_alt_PT <- -2*(model_g_LnL-model_a_LnL)
degrees.of.freedom <- model_a_np-model_g_np
p.value_gen_alt_PT <- 1-pchisq(LRT_gen_alt_PT,df=degrees.of.freedom)
LRT_gen_alt_PT
p.value_gen_alt_PT

