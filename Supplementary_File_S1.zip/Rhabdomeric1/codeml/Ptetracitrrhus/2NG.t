     7
Ovulgaris            
Emoschata              0.3729
Cmacropus              0.2113  0.4157
Ecirrhosa              0.3252  0.1326  0.4067
Ptetracitrrhus         0.2252  0.4163  0.1470  0.3961
Sunicirrhus            0.2395  0.3315  0.1633  0.2653  0.1836
Aargo                  0.4099  0.4884  0.4372  0.4524  0.4454  0.4096
