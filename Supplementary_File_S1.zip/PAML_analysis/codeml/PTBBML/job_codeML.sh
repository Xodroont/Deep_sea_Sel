#!/bin/bash
#SBATCH --job-name=codeml_batch
#SBATCH --partition=all
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=8G
#SBATCH --time=24:00:00
#SBATCH --output=codeml_%j.out
#SBATCH --error=codeml_%j.err
#SBATCH --mail-user=giacinto.devivo@szn.it
#SBATCH --mail-type=END,FAIL

module load paml/4.10.7

srun codeml "/bee/userdata/gdevivo/PAML/CodeML/deep/Rhabdomeric1.codeml.m0.ctl"
srun codeml "/bee/userdata/gdevivo/PAML/CodeML/deep/Rhabdomeric1.codeml.m1.ctl"
srun codeml "/bee/userdata/gdevivo/PAML/CodeML/deep/Rhabdomeric1.codeml.msitres_gen.ctl"
srun codeml "/bee/userdata/gdevivo/PAML/CodeML/deep/Rhabdomeric1.codeml.msitres_alt.ctl"