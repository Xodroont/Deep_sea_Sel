     7
Ovulgaris            
Emoschata              0.3479
Cmacropus              0.2100  0.3948
Ecirrhosa              0.3227  0.1103  0.4081
Ptetracirrhus          0.2240  0.3949  0.1452  0.3969
Sunicirrhus            0.2403  0.3134  0.1640  0.2704  0.1839
Aargo                  0.4059  0.4669  0.4362  0.4550  0.4438  0.4127
